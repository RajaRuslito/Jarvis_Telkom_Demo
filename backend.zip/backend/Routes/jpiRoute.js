const express = require('express');

const {
  createJPI,
  jpiUpdate,
  getAllJPI,
  getJPIById,
  deleteJPI,
  uploadXLSX, 
  downloadXLSX,
  upload
} = require('../Controllers/jpiController');

const router = express.Router();

const uploadMiddleware = upload.fields([
   { name: "file", maxCount: 1 },
   { name: "job_id", maxCount: 1 },
   { name: "nama_job", maxCount: 1 },
   { name: "deskripsi", maxCount: 1 },
]);

// Route to create a new report
router.post("/create", uploadMiddleware, createJPI);

router.put('/:job_id/update', uploadMiddleware, async (req, res) => {
   await jpiUpdate(req, res);
});

router.get('/', async (req, res) => {
   await getAllJPI(req, res);
});

router.get('/:job_id', async (req, res) => {
   await getJPIById(req, res);
});

router.delete('/:job_id/delete', async (req, res) => {
   await deleteJPI(req, res);
});

router.post("/upload-xlsx", upload.single("file"), uploadXLSX);

router.get("/download", downloadXLSX);

module.exports = router;