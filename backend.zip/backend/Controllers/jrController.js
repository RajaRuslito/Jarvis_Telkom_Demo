const multer = require("multer");
const pool = require('../db');
const upload = require("../middleware/multer");
const xlsx = require("xlsx");
const fs = require("fs");

async function createJR (req, res){
    const job_id = parseInt(req.body.job_id, 10);
    const { nama_job, deskripsi } = req.body;

    if (!job_id || !nama_job || !deskripsi) {
        console.error("Missing Fields:", { job_id, nama_job, deskripsi });
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    try {
        const query = `
        INSERT INTO job_req (job_id, nama_job, deskripsi)
        VALUES ($1, $2, $3)
        ON CONFLICT (job_id)
        DO UPDATE SET 
            nama_job = EXCLUDED.nama_job,
            deskripsi = EXCLUDED.deskripsi
        RETURNING *; 
        `;
        const values = [job_id, nama_job, deskripsi];

        const { rows } = await pool.query(query, values);
        const operation = rows[0].operation_type;
        if (operation === "created") {
            console.log(`✅ New mission statement created for job_id: ${job_id}`);
            res.status(201).json({
                success: true,
                message: `Mission statement ${operation} successfully`,
                data: rows[0],
            });
        } else {
            console.log(`♻️ Existing mission statement updated for job_id: ${job_id}`);
            res.status(201).json({
                success: true,
                message: `Mission statement updated successfully`,
                data: rows[0],
            });
        }
    } catch (error) {
        console.error("Error creating mission statement:", error.message);
        res.status(500).json({ success: false, message: error.message });
    }
}

// Upload XLSX and Insert Data
async function uploadXLSX(req, res){
    try {
        if (!req.file) {
            return res.status(400).json({ error: "No file uploaded" });
        }

        const filePath = req.file.path;
        const workbook = xlsx.readFile(filePath);
        const sheetName = workbook.SheetNames[0];
        const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
       
        let insertedCount = 0;
        let updatedCount = 0;

        for (const row of data) {
            if (!row.job_id || !row.nama_job || !row.deskripsi) {
                console.error("Skipping row due to missing fields:", row);
                continue;
            }
            const checkQuery = `SELECT * FROM job_req WHERE job_id = $1`;
            const existingJob = await pool.query(checkQuery, [parseInt(row.job_id)]);

            if (existingJob.rows.length > 0) {
                // If job_id exists, update the record
                const updateQuery = `
                    UPDATE job_req 
                    SET nama_job = $1, deskripsi = $2 
                    WHERE job_id = $3 RETURNING *;
                `;
                await pool.query(updateQuery, [row.nama_job, row.deskripsi, row.job_id]);
                console.log(`Updated job_id: ${row.job_id}`);
                updatedCount++;
            } else {
                // If job_id does not exist, insert new record
                const insertQuery = `
                    INSERT INTO job_req (job_id, nama_job, deskripsi)
                    VALUES ($1, $2, $3) RETURNING *;
                `;
                      
                await pool.query(insertQuery, [parseInt(row.job_id), row.nama_job, row.deskripsi]);
                console.log(`Inserted new job_id: ${row.job_id}`);
                insertedCount++;
            }
        }

        // Delete the file after processing
        fs.unlinkSync(filePath);

        res.status(201).json({ 
            message: "XLSX file uploaded and data inserted successfully!",
            inserted: insertedCount,
            updated: updatedCount 
        });
    } catch (error) {
        console.error("Error uploading XLSX:", error);
        res.status(500).json({ error: "An error occurred while processing the file" });
    }
}

// Download XLSX masih belom bisa skip aja
async function downloadXLSX(req, res) {
    try {
        console.log("🔍 Checking job_req table...");
        
        // Fetch data from the database
        const result = await pool.query("SELECT * FROM job_req;");
        
        if (result.rows.length === 0) {
            console.warn("⚠️ No data found in job_req table.");
            return res.status(404).json({ error: "No records found to export." }); // Adjusted error message
        }

        console.log(`📝 Retrieved ${result.rows.length} records from job_req`);

        // Convert data into worksheet
        const worksheet = xlsx.utils.json_to_sheet(result.rows);
        const workbook = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(workbook, worksheet, "JobRequirement");

        // Define file path
        const filePath = path.join(__dirname, "../downloads/job_requirements.xlsx");

        // Ensure the downloads directory exists
        if (!fs.existsSync(path.dirname(filePath))) {
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
        }

        // Write file to the server
        xlsx.writeFile(workbook, filePath);
        console.log(`✅ XLSX file created at ${filePath}`);

        // Send the file for download
        res.download(filePath, "job_requirements.xlsx", (err) => {
            if (err) {
                console.error("Error sending file:", err);
                res.status(500).json({ error: "Error downloading the file" });
            } else {
                console.log("✅ File download initiated successfully.");
            }
        });

    } catch (error) {
        console.error("❌ Error downloading XLSX:", error);
        res.status(500).json({ error: "An error occurred while generating the file" });
    }
}

async function jrUpdate(req, res) {
    const job_id = parseInt(req.params.job_id, 10);
    const { nama_job, deskripsi } = req.body;
    try {
        const result = await pool.query(
            `UPDATE job_req 
             SET nama_job = $1, deskripsi = $2 
             WHERE job_id = $3 RETURNING *`,
            [nama_job, deskripsi, job_id]
        );
        if (result.rows.length === 0) {
            res.status(404).json({ error: 'job_req not found' });
        } else {
            res.json(result.rows[0]);
        }
    } catch (error) {
        console.error('Error updating job_req:', error);
        res.status(500).json({ error: 'Error updating job_req' });
    }
}

async function getAllJR(req, res) {
    try {
        const result = await pool.query(`SELECT * FROM job_req`);
        res.json(result.rows);
    } catch (error) {
        console.error('Error getting Job Requirement:', error);
        res.status(500).json({ error: 'Error getting Job Requirement' });
    }
}

// Get report by ID
async function getJRById(req, res) {
    const { job_id } = req.params;
    try {
        const result = await pool.query(`SELECT * FROM job_req WHERE job_id = $1`, [job_id]);
        if (result.rows.length === 0) {
            res.status(404).json({ error: 'Requirement not found' });
        } else {
            res.json(result.rows[0]);
        }
    } catch (error) {
        console.error('Error getting job_req by ID:', error);
        res.status(500).json({ error: 'Error getting job_req by ID' });
    }
}

async function deleteJR(req, res) {
    const { job_id } = req.params;

    try {
        const result = await pool.query(
            'DELETE FROM job_req WHERE job_id = $1 RETURNING *',
            [job_id]
        );
        if (result.rows.length === 0) {
            res.status(404).json({ error: 'Job Requirement not found' });
        } else {
            res.json({ message: 'Job Requirement deleted successfully' });
        }
    } catch (error) {
        console.error('Error deleting Job Requirement:', error);
        res.status(500).json({ error: 'Error deleting Job Requirement' });
    }
}

module.exports = {
    createJR,
    jrUpdate,
    getAllJR,
    getJRById,
    deleteJR,
    uploadXLSX,
    downloadXLSX,
    upload
};